#!/usr/bin/env python3
# /lf/lowstate (unitree_go/msg/LowState) 의 12개 모터 각도를
# URDF 관절 이름에 매칭해 /joint_states 로 뿌린다.
# -> 로봇 모델 다리가 실제 로봇과 똑같이 접힌다.
#
# Go2 motor_state 순서(0~11): 다리=FR,FL,RR,RL / 각 다리=hip,thigh,calf
import rclpy
from rclpy.node import Node
from unitree_go.msg import LowState
from sensor_msgs.msg import JointState

# 모터 인덱스(0~11) -> URDF joint 이름
JOINT_NAMES = [
    'FR_hip_joint', 'FR_thigh_joint', 'FR_calf_joint',
    'FL_hip_joint', 'FL_thigh_joint', 'FL_calf_joint',
    'RR_hip_joint', 'RR_thigh_joint', 'RR_calf_joint',
    'RL_hip_joint', 'RL_thigh_joint', 'RL_calf_joint',
]


class LowstateToJoints(Node):
    def __init__(self):
        super().__init__('lowstate_to_joints')
        self.pub = self.create_publisher(JointState, '/joint_states', 10)
        self.sub = self.create_subscription(
            LowState, '/lf/lowstate', self.cb, 10)
        self.n = 0
        self.get_logger().info('lowstate_to_joints 시작: /lf/lowstate -> /joint_states (12관절)')

    def cb(self, msg: LowState):
        js = JointState()
        js.header.stamp = self.get_clock().now().to_msg()
        js.name = JOINT_NAMES
        js.position = [float(msg.motor_state[i].q) for i in range(12)]
        self.pub.publish(js)
        self.n += 1
        if self.n % 100 == 0:
            self.get_logger().info(f'관절 방송 중... {self.n} 프레임')


def main():
    rclpy.init()
    node = LowstateToJoints()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
