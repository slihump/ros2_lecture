#!/usr/bin/env python3
# Go2 TF 백엔드 (odom->base_link TF + 로봇 3D 모델)
#   - /utlidar/robot_odom  -> (odom_to_tf)       -> odom->base_link TF
#   - /lf/lowstate         -> (lowstate_to_joints)-> /joint_states (다리 실제 자세)
#   - go2_description_abs.urdf -> robot_state_publisher -> 로봇 뼈대 TF + /robot_description
# 결과 TF 사슬:  odom -> base_link -> base -> (온몸)
# 실행:  go2ros && ros2 launch ~/ws/go2_tf/go2_tf.launch.py
#
# ※ 2026-07-16 복구: 이 파일이 실수로 덮어써져 zip(go2_robot_model) 런치를 참고해 재작성함.
import os
import sys
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

# 이 launch 파일이 있는 폴더 = go2_tf
PKG = os.path.dirname(os.path.abspath(__file__))
URDF = os.path.join(PKG, 'go2_description_abs.urdf')   # mesh 경로가 package:// 인 URDF
ODOM = os.path.join(PKG, 'odom_to_tf.py')
JOINTS = os.path.join(PKG, 'lowstate_to_joints.py')

sys.path.insert(0, PKG)
from robot_description import load_robot_description   # noqa: E402


def generate_launch_description():
    # URDF 읽기 (package://go2_description/... -> 이 PC 의 실제 mesh 경로로 치환)
    robot_desc = load_robot_description(URDF)

    return LaunchDescription([
        # 1) URDF -> 로봇 뼈대 TF + /robot_description (RViz RobotModel용)
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'robot_description': robot_desc, 'use_sim_time': False}],
        ),
        # 2) 실제 로봇 관절각(/lf/lowstate) -> /joint_states
        ExecuteProcess(cmd=['python3', JOINTS], output='screen'),
        # 3) URDF 뿌리(base)를 로봇 odom 자식(base_link)에 연결
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='base_link_to_base',
            arguments=['0', '0', '0', '0', '0', '0', 'base_link', 'base'],
        ),
        # 4) 로봇 위치(/utlidar/robot_odom) -> TF(odom -> base_link)
        ExecuteProcess(cmd=['python3', ODOM], output='screen'),
    ])
