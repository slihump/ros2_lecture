#!/usr/bin/env python3
# URDF 로더 (경로 하드코딩 제거용, 2026-08-05)
# ─────────────────────────────────────────────────────────────
# go2_description_abs.urdf 안의 mesh 경로는 ROS 표준 표기인
#   package://go2_description/dae/xxx.dae
# 로 되어 있다. RViz2 는 go2_description 이 colcon 으로 빌드된 ROS2 패키지일 때만
# 이 표기를 스스로 풀 수 있는데, 여기서는 unitree_ros 레포를 그냥 clone 해서
# 쓰기 때문에 패키지가 아니다. 그래서 launch 시점에 우리가 직접 실제 경로로
# 치환해서 robot_description 파라미터에 넣는다.
#
# 덕분에 URDF 에는 /home/xxx 같은 절대경로가 하나도 남지 않고,
# 다른 PC 로 폴더째 옮겨도 아래 탐색 순서로 알아서 찾는다.
#
# 탐색 순서:
#   1) $GO2_DESCRIPTION_DIR        (go2_description 폴더를 직접 지정 — 최우선)
#   2) ament index                 (go2_description 을 ROS2 패키지로 빌드해 둔 경우)
#   3) $UNITREE_ROS_DIR/robots/go2_description
#   4) 흔한 위치들 (~/ws/unitree_ros, ~/unitree_ros, 이 파일의 상위 폴더 옆 등)
import os

PKG = 'go2_description'
_HERE = os.path.dirname(os.path.abspath(__file__))   # = go2_tf


def _looks_valid(path):
    """dae/base.dae 가 실제로 있는 go2_description 폴더인지 확인."""
    return bool(path) and os.path.isfile(os.path.join(path, 'dae', 'base.dae'))


def find_description_dir():
    """go2_description 폴더의 절대경로를 반환. 못 찾으면 RuntimeError."""
    # 1) 사용자가 직접 지정
    if _looks_valid(os.environ.get('GO2_DESCRIPTION_DIR')):
        return os.environ['GO2_DESCRIPTION_DIR']

    # 2) ROS2 패키지로 빌드해 둔 경우
    try:
        from ament_index_python.packages import get_package_share_directory
        share = get_package_share_directory(PKG)
        if _looks_valid(share):
            return share
    except Exception:
        pass

    # 3) + 4) unitree_ros 레포 위치 후보
    home = os.path.expanduser('~')
    repo_candidates = [
        os.environ.get('UNITREE_ROS_DIR'),
        os.path.join(home, 'ws', 'unitree_ros'),
        os.path.join(home, 'unitree_ros'),
        os.path.join(_HERE, '..', 'unitree_ros'),          # go2_tf 의 형제 폴더
        os.path.join(_HERE, '..', '..', 'unitree_ros'),
    ]
    for repo in repo_candidates:
        if not repo:
            continue
        cand = os.path.normpath(os.path.join(repo, 'robots', PKG))
        if _looks_valid(cand):
            return cand

    raise RuntimeError(
        f"{PKG} 폴더를 찾지 못했습니다 (mesh 파일 위치).\n"
        "  해결 1) git clone --depth 1 "
        "https://github.com/unitreerobotics/unitree_ros.git ~/ws/unitree_ros\n"
        "  해결 2) 이미 받아뒀다면 위치를 알려주세요:\n"
        "          export UNITREE_ROS_DIR=/받은/경로/unitree_ros\n"
        "     또는  export GO2_DESCRIPTION_DIR=/받은/경로/unitree_ros/robots/go2_description"
    )


def load_robot_description(urdf_path):
    """URDF 를 읽어 package:// 를 실제 file:// 절대경로로 치환한 문자열 반환."""
    with open(urdf_path, 'r') as f:
        xml = f.read()
    mesh_dir = find_description_dir()
    return xml.replace(f'package://{PKG}/', 'file://' + mesh_dir + '/')
