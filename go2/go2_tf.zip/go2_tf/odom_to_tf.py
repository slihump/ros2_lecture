#!/usr/bin/env python3
# /utlidar/robot_odom (nav_msgs/Odometry) 토픽을 받아서
# odom -> base_link 변환을 TF로 방송하는 작은 노드.
# Go2 브리지는 TF를 안 뿌리므로 이 노드가 그 다리 역할을 한다.
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped


class OdomToTF(Node):
    def __init__(self):
        super().__init__('odom_to_tf')
        self.br = TransformBroadcaster(self)
        self.sub = self.create_subscription(
            Odometry, '/utlidar/robot_odom', self.cb, 10)
        self.n = 0
        self.get_logger().info('odom_to_tf 시작: /utlidar/robot_odom -> TF(odom->base_link)')

    def cb(self, msg: Odometry):
        t = TransformStamped()
        t.header.stamp = msg.header.stamp
        t.header.frame_id = msg.header.frame_id or 'odom'          # odom
        t.child_frame_id = msg.child_frame_id or 'base_link'       # base_link
        p = msg.pose.pose.position
        q = msg.pose.pose.orientation
        t.transform.translation.x = p.x
        t.transform.translation.y = p.y
        t.transform.translation.z = p.z
        t.transform.rotation = q
        self.br.sendTransform(t)
        self.n += 1
        if self.n % 100 == 0:
            self.get_logger().info(f'방송 중... {self.n} 프레임')


def main():
    rclpy.init()
    node = OdomToTF()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
