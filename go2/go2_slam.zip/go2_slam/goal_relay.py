#!/usr/bin/env python3
# rviz "2D Goal Pose" 버튼(/goal_pose) -> Nav2 navigate_to_pose 액션 호출.
# 이게 있어야 rviz에서 목표 찍으면 Nav2가 자율주행 시작함.
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose


class GoalRelay(Node):
    def __init__(self):
        super().__init__('goal_relay')
        self.client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.sub = self.create_subscription(PoseStamped, '/goal_pose', self.cb, 10)
        self.get_logger().info('goal_relay 시작: /goal_pose -> navigate_to_pose (rviz 목표 찍으면 출발)')

    def cb(self, msg: PoseStamped):
        if not self.client.wait_for_server(timeout_sec=3.0):
            self.get_logger().error('navigate_to_pose 액션 서버 없음 (Nav2 떴는지 확인)')
            return
        goal = NavigateToPose.Goal()
        goal.pose = msg
        p = msg.pose.position
        self.get_logger().info(f'목표 전송 -> ({p.x:.2f}, {p.y:.2f})')
        fut = self.client.send_goal_async(goal)
        fut.add_done_callback(self._accepted)

    def _accepted(self, fut):
        gh = fut.result()
        if gh and gh.accepted:
            self.get_logger().info('목표 수락됨 — 주행 시작')
            gh.get_result_async().add_done_callback(
                lambda f: self.get_logger().info('주행 종료(도착 or 중단)'))
        else:
            self.get_logger().warn('목표 거부됨')


def main():
    rclpy.init()
    node = GoalRelay()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
