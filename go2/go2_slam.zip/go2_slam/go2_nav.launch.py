# Go2 Nav2 (1.8 ③) — 라이브 slam_toolbox(map, map->odom) 위에서 목표점 자율주행.
# collision_monitor / velocity_smoother 없이 핵심 노드만 (컨트롤러가 /cmd_vel 직접 발행).
# 전제: go2_tf + slam(go2_mapping) + cmd_vel_to_sport 브리지가 떠 있어야 함.
# 실행(기본=RPP+Rotation Shim, 2026-07-21 승격): go2ros && ros2 launch ~/ws/go2_slam/go2_nav.launch.py
# 순수 RPP로:  ... params:=/home/wonho/ws/go2_slam/config/nav2_params.yaml
# MPPI로:      ... params:=/home/wonho/ws/go2_slam/config/nav2_params_mppi.yaml
import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

# 2026-07-21: 기본을 RPP+Rotation Shim으로 승격(제자리회전 시작+도착까지). 순수 RPP/MPPI는 params 인자로 선택.
DEFAULT_PARAMS = os.path.expanduser('~/ws/go2_slam/config/nav2_params_shim.yaml')
RELAY = os.path.expanduser('~/ws/go2_slam/goal_relay.py')

LIFECYCLE_NODES = ['controller_server', 'planner_server',
                   'behavior_server', 'bt_navigator']


def generate_launch_description():
    common = {'use_sim_time': False}
    params = LaunchConfiguration('params')
    return LaunchDescription([
        DeclareLaunchArgument(
            'params', default_value=DEFAULT_PARAMS,
            description='Nav2 파라미터 파일. 기본=RPP+Rotation Shim(nav2_params_shim.yaml). '
                        '순수 RPP=nav2_params.yaml / MPPI=nav2_params_mppi.yaml'),
        Node(package='nav2_controller', executable='controller_server',
             name='controller_server', output='screen',
             parameters=[params, common], remappings=[('cmd_vel', '/cmd_vel')]),
        Node(package='nav2_planner', executable='planner_server',
             name='planner_server', output='screen', parameters=[params, common]),
        Node(package='nav2_behaviors', executable='behavior_server',
             name='behavior_server', output='screen', parameters=[params, common]),
        Node(package='nav2_bt_navigator', executable='bt_navigator',
             name='bt_navigator', output='screen', parameters=[params, common]),
        Node(package='nav2_lifecycle_manager', executable='lifecycle_manager',
             name='lifecycle_manager_navigation', output='screen',
             parameters=[{'use_sim_time': False,
                          'autostart': True,
                          'node_names': LIFECYCLE_NODES}]),
        # rviz 목표(/goal_pose) -> navigate_to_pose 액션
        ExecuteProcess(cmd=['python3', RELAY], name='goal_relay', output='screen'),
    ])
