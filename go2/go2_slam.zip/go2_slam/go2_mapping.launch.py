# Go2 매핑 파이프라인 (1.8 ①)
#   /utlidar/cloud_base(3D, base_link) -> /scan(2D) -> slam_toolbox -> /map, map->odom TF
# 전제: go2_tf 백엔드(odom->base_link TF)가 이미 떠 있어야 함.
# 실행:  go2ros && ros2 launch ~/ws/go2_slam/go2_mapping.launch.py
import os
import launch
from launch import LaunchDescription
from launch.actions import EmitEvent, RegisterEventHandler
from launch_ros.actions import Node, LifecycleNode
from launch_ros.event_handlers import OnStateTransition
from launch_ros.events.lifecycle import ChangeState
from lifecycle_msgs.msg import Transition

SLAM_CFG = os.path.expanduser('~/ws/go2_slam/config/slam_params.yaml')


def generate_launch_description():
    # 3D 점구름 -> 2D 라인 스캔
    p2l = Node(
        package='pointcloud_to_laserscan',
        executable='pointcloud_to_laserscan_node',
        name='pointcloud_to_laserscan',
        remappings=[('cloud_in', '/utlidar/cloud_base')],
        parameters=[{
            'target_frame': 'base_link',
            'transform_tolerance': 0.05,
            'min_height': 0.15,    # 0.05는 보행 시 몸 기울면 바닥이 벽으로 찍힘(지도 노이즈 주범) → 상향
            'max_height': 0.45,    # 천장/가구윗면 배제, 벽 높이만
            'angle_min': -3.14159,
            'angle_max': 3.14159,
            'angle_increment': 0.0087,
            'scan_time': 0.066,
            'range_min': 0.20,
            'range_max': 12.0,
            'use_inf': True,
        }],
        output='screen',
    )

    # 2D SLAM (lifecycle 노드 — 자동 configure+activate)
    slam = LifecycleNode(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        namespace='',
        parameters=[SLAM_CFG],
        output='screen',
    )

    # 시작 -> configure
    to_configure = EmitEvent(event=ChangeState(
        lifecycle_node_matcher=launch.events.matches_action(slam),
        transition_id=Transition.TRANSITION_CONFIGURE,
    ))
    # inactive 도달 -> activate
    to_activate = RegisterEventHandler(OnStateTransition(
        target_lifecycle_node=slam,
        goal_state='inactive',
        entities=[EmitEvent(event=ChangeState(
            lifecycle_node_matcher=launch.events.matches_action(slam),
            transition_id=Transition.TRANSITION_ACTIVATE,
        ))],
    ))

    return LaunchDescription([p2l, slam, to_configure, to_activate])
