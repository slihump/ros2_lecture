#!/usr/bin/env python3
# Go2 FAST-LIO2 localization 백엔드 (선임 G1 방식 각색, 2026-07-16)
# ─────────────────────────────────────────────────────────────
# 기존 (go2_tf + go2_localization = odom_to_tf + AMCL) 을 대체한다.
#   위치추정: FAST-LIO2 정밀 odom + RViz 초기자세로 map 정렬 (AMCL 없음)
#
# 이 런치가 띄우는 것:
#   1) tf_rename            : FAST-LIO(camera_init->body) -> odom->base_link  [odom_to_tf 대체]
#   2) initialpose_to_map_odom : RViz 2D Pose Estimate(/initialpose) -> map->odom  [AMCL 대체]
#   3) map_server(+lifecycle)  : 저장 2D 지도(go2_room_2d) 발행
#   4) robot_state_publisher + lowstate_to_joints + static base_link->base : 로봇 3D 모델
#   5) pointcloud_to_laserscan : L1(/utlidar/cloud_base) -> /scan  (로컬 코스트맵 장애물용)
#
# ⚠️ 전제(다른 터미널에서 먼저/함께 실행):
#   - FAST-LIO XT16 파이프라인이 돌아 camera_init->body TF + /Odometry 를 발행 중이어야 함
#     (hesai 드라이버 + xt16_fastlio_bridge.py + FAST-LIO)
#   - Nav2 코어: ros2 launch ~/ws/go2_slam/go2_nav.launch.py
#   - 조종 브리지: python3 ~/ws/go2_ctrl/cmd_vel_to_sport.py   (api 1008)
#   - RViz: rviz2 -d ~/ws/go2_slam/go2_nav.rviz
#
# TF 사슬 결과:  map -> odom -> base_link -> base -> (URDF 온몸)
# 실행:  go2ros && ros2 launch ~/ws/go2_slam/go2_navigation2.launch.py
import os
import sys
from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

HOME = os.path.expanduser('~')
GO2_SLAM = os.path.join(HOME, 'ws', 'go2_slam')
GO2_TF = os.path.join(HOME, 'ws', 'go2_tf')

URDF = os.path.join(GO2_TF, 'go2_description_abs.urdf')
LOWSTATE = os.path.join(GO2_TF, 'lowstate_to_joints.py')
TF_RENAME = os.path.join(GO2_SLAM, 'tf_rename.py')
INITIALPOSE = os.path.join(GO2_SLAM, 'initialpose_to_map_odom.py')
MAP_YAML = os.path.join(HOME, 'ws', 'go2_3d', 'maps', 'go2_room_2d.yaml')

sys.path.insert(0, GO2_TF)
from robot_description import load_robot_description   # noqa: E402


def generate_launch_description():
    # URDF 의 package://go2_description/... 를 이 PC 의 실제 mesh 경로로 치환
    robot_desc = load_robot_description(URDF)

    # 1) FAST-LIO(camera_init->body) -> odom->base_link  (odom_to_tf 대체)
    tf_rename = ExecuteProcess(
        cmd=['python3', TF_RENAME, '--ros-args',
             '-p', 'src_parent:=camera_init',
             '-p', 'src_child:=body',
             '-p', 'dst_parent:=odom',
             '-p', 'dst_child:=base_link',
             '-p', 'z_lift:=0.0'],          # Go2: 리프트 없음(2D 주행엔 z 무관)
        output='screen',
    )

    # 2) RViz 초기자세(/initialpose) -> map->odom TF  (AMCL 대체)
    initialpose = ExecuteProcess(
        cmd=['python3', INITIALPOSE, '--ros-args',
             '-p', 'map_frame:=map',
             '-p', 'odom_frame:=odom',
             '-p', 'base_frame:=base_link',
             '-p', 'start_identity:=true',
             '-p', 'publish_rate:=20.0'],
        output='screen',
    )

    # 3) 저장 2D 지도 발행
    map_server = Node(
        package='nav2_map_server', executable='map_server', name='map_server',
        output='screen',
        parameters=[{'use_sim_time': False,
                     'yaml_filename': MAP_YAML,
                     'topic_name': 'map',
                     'frame_id': 'map'}],
    )
    lifecycle_map = Node(
        package='nav2_lifecycle_manager', executable='lifecycle_manager',
        name='lifecycle_manager_localization', output='screen',
        parameters=[{'use_sim_time': False,
                     'autostart': True,
                     'node_names': ['map_server']}],
    )

    # 4) 로봇 3D 모델 (base_link->base->온몸)
    rsp = Node(
        package='robot_state_publisher', executable='robot_state_publisher',
        name='robot_state_publisher', output='screen',
        parameters=[{'robot_description': robot_desc, 'use_sim_time': False}],
    )
    joints = ExecuteProcess(cmd=['python3', LOWSTATE], output='screen')
    base_link_to_base = Node(
        package='tf2_ros', executable='static_transform_publisher',
        name='base_link_to_base',
        arguments=['0', '0', '0', '0', '0', '0', 'base_link', 'base'],
    )

    # base_link -> hesai_lidar (XT16 장착 외부파라미터: 앞 0.25m, yaw +90°)
    #   FAST-LIO xt16.yaml extrinsic_T=[0.25,0,0], extrinsic_R=Rz(+90°) 그대로.
    #   이걸 깔아야 /velodyne_points(hesai_lidar 프레임)를 코스트맵이 base_link로 변환 가능.
    base_link_to_hesai = Node(
        package='tf2_ros', executable='static_transform_publisher',
        name='base_link_to_hesai',
        arguments=['0.25', '0', '0', '1.5708', '0', '0', 'base_link', 'hesai_lidar'],
    )

    # 5) XT16 360° 점구름 -> 2D /scan (로컬/글로벌 코스트맵 장애물 감지용)
    #    ★ 2026-07-20: L1(/utlidar/cloud_base)에서 XT16(/velodyne_points)로 교체.
    #    L1은 전방 84%만 보는 전방지향 센서라 회전/측면에서 벽을 못 봐 충돌했음.
    #    XT16은 진짜 360°(방위 균일)라 사방 벽을 다 감지. 브리지 경유 PC시계라 TF와도 일치.
    #    height 밴드/ range_min은 실측 튜닝 대상(바닥이 장애물로 찍히면 min_height↑).
    p2l = Node(
        package='pointcloud_to_laserscan',
        executable='pointcloud_to_laserscan_node',
        name='pointcloud_to_laserscan',
        remappings=[('cloud_in', '/velodyne_points')],
        parameters=[{
            'target_frame': 'base_link',
            'transform_tolerance': 0.1,
            'min_height': -0.2,   # 라이다 레벨 기준 벽 밴드(바닥 제외). 바닥이 찍히면 올릴 것
            'max_height': 0.5,
            'angle_min': -3.14159,
            'angle_max': 3.14159,
            'angle_increment': 0.0087,
            'scan_time': 0.1,
            'range_min': 0.4,    # 로봇 자기몸/안테나 반사 제외
            'range_max': 12.0,
            'use_inf': True,
        }],
        output='screen',
    )

    return LaunchDescription([
        tf_rename,
        initialpose,
        map_server,
        lifecycle_map,
        rsp,
        joints,
        base_link_to_base,
        base_link_to_hesai,
        p2l,
    ])
