#!/usr/bin/env python3

import math
import rclpy
from rclpy.node import Node
from rclpy.time import Time
from rclpy.duration import Duration

from geometry_msgs.msg import PoseWithCovarianceStamped, TransformStamped
from tf2_ros import Buffer, TransformListener, TransformBroadcaster


def yaw_from_quat(q):
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)

def quat_from_yaw(yaw):
    half = 0.5 * yaw
    return (0.0, 0.0, math.sin(half), math.cos(half))  # x, y, z, w

def norm_angle(a):
    # [-pi, pi]
    while a > math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


class InitialPoseToMapOdom(Node):
    def __init__(self):
        super().__init__('initialpose_to_map_odom')
        self.base_frame = self.declare_parameter('base_frame', 'pelvis').get_parameter_value().string_value
        self.odom_frame = self.declare_parameter('odom_frame', 'odom').get_parameter_value().string_value
        self.map_frame  = self.declare_parameter('map_frame',  'map').get_parameter_value().string_value
        self.start_identity = self.declare_parameter('start_identity', True).get_parameter_value().bool_value
        publish_rate = float(self.declare_parameter('publish_rate', 20.0).get_parameter_value().double_value)

        self.buf = Buffer()
        self.tl  = TransformListener(self.buf, self)
        self.br  = TransformBroadcaster(self)

        self.current_tf = TransformStamped()
        self.current_tf.header.frame_id = self.map_frame
        self.current_tf.child_frame_id  = self.odom_frame

        self.have_override = False

        if self.start_identity:
            self._set_tf(0.0, 0.0, 0.0)
            self.have_override = True
            self.get_logger().info(f"[init] Identity {self.map_frame}->{self.odom_frame} publish ON")

        self.sub = self.create_subscription(
            PoseWithCovarianceStamped, '/initialpose', self.on_initialpose, 10
        )

        self.timer = self.create_timer(1.0 / max(1.0, publish_rate), self.on_timer)

        self.get_logger().info(
            f"Listening on /initialpose to set {self.map_frame}->{self.odom_frame} (base={self.base_frame})"
        )

    def _set_tf(self, x, y, yaw):
        qx, qy, qz, qw = quat_from_yaw(yaw)
        self.current_tf.header.stamp = self.get_clock().now().to_msg()
        self.current_tf.transform.translation.x = x
        self.current_tf.transform.translation.y = y
        self.current_tf.transform.translation.z = 0.0
        self.current_tf.transform.rotation.x = qx
        self.current_tf.transform.rotation.y = qy
        self.current_tf.transform.rotation.z = qz
        self.current_tf.transform.rotation.w = qw

    def on_initialpose(self, msg: PoseWithCovarianceStamped):
        px = msg.pose.pose.position.x
        py = msg.pose.pose.position.y
        yaw = yaw_from_quat(msg.pose.pose.orientation)

        try:
            tf_odom_base = self.buf.lookup_transform(
                self.odom_frame, self.base_frame, Time(), timeout=Duration(seconds=0.2)
            )
        except Exception as e:
            self.get_logger().warn(f"lookup {self.odom_frame}->{self.base_frame} failed: {e}")
            return

        obx = tf_odom_base.transform.translation.x
        oby = tf_odom_base.transform.translation.y
        ob_yaw = yaw_from_quat(tf_odom_base.transform.rotation)
        
        c_inv = math.cos(-ob_yaw); s_inv = math.sin(-ob_yaw)
        tx = -(c_inv * obx - s_inv * oby)
        ty = -(s_inv * obx + c_inv * oby)

        c = math.cos(yaw); s = math.sin(yaw)
        mx = px + (c * tx - s * ty)
        my = py + (s * tx + c * ty)
        myaw = norm_angle(yaw - ob_yaw)

        self._set_tf(mx, my, myaw)
        self.have_override = True

        self.get_logger().info(
            f"Set {self.map_frame}->{self.odom_frame}: x={mx:.3f}, y={my:.3f}, yaw={myaw:.3f} rad"
        )

    def on_timer(self):
        if self.have_override:
            self.current_tf.header.stamp = self.get_clock().now().to_msg()
            self.br.sendTransform(self.current_tf)


def main():
    rclpy.init()
    node = InitialPoseToMapOdom()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
