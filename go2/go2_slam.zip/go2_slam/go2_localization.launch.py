# Go2 위치추정 파이프라인 (1.8 ③ — 저장한 맵 위에서 주행)
#   /utlidar/cloud_base(3D) -> /scan(2D) -> [map_server(저장맵) + AMCL] -> /map, map->odom TF
# slam_toolbox(mapping) 대신 이걸 띄우면 "저장한 맵"이 그대로 뜨고 그 위에서 Nav2 주행.
# 전제: go2_tf 백엔드(odom->base_link TF)가 이미 떠 있어야 함.
# 실행:  go2ros && ros2 launch ~/ws/go2_slam/go2_localization.launch.py
import os
from launch import LaunchDescription
from launch_ros.actions import Node

AMCL_CFG = os.path.expanduser('~/ws/go2_slam/config/amcl_params.yaml')

# 저장맵 위 주행에서 lifecycle_manager가 켜고 활성화할 노드
LIFECYCLE_NODES = ['map_server', 'amcl']


def generate_launch_description():
    # 3D 점구름 -> 2D 라인 스캔 (매핑 때와 동일 파라미터)
    p2l = Node(
        package='pointcloud_to_laserscan',
        executable='pointcloud_to_laserscan_node',
        name='pointcloud_to_laserscan',
        remappings=[('cloud_in', '/utlidar/cloud_base')],
        parameters=[{
            'target_frame': 'base_link',
            'transform_tolerance': 0.05,
            'min_height': 0.15,   # 매핑과 동일하게 유지(보행 기울기 시 바닥 오인식 방지)
            'max_height': 0.45,
            'angle_min': -3.14159,
            'angle_max': 3.14159,
            'angle_increment': 0.0087,
            'scan_time': 0.066,
            'range_min': 0.35,   # 랜선 회피용 (자기몸반사 제외)
            'range_max': 12.0,
            'use_inf': True,
        }],
        output='screen',
    )

    # 저장맵 발행 (lifecycle)
    map_server = Node(
        package='nav2_map_server', executable='map_server', name='map_server',
        parameters=[AMCL_CFG], output='screen',
    )

    # 위치추정 (lifecycle)
    amcl = Node(
        package='nav2_amcl', executable='amcl', name='amcl',
        parameters=[AMCL_CFG], output='screen',
    )

    # map_server + amcl 자동 configure+activate
    lifecycle = Node(
        package='nav2_lifecycle_manager', executable='lifecycle_manager',
        name='lifecycle_manager_localization', output='screen',
        parameters=[{'use_sim_time': False,
                     'autostart': True,
                     'node_names': LIFECYCLE_NODES}],
    )

    return LaunchDescription([p2l, map_server, amcl, lifecycle])
