#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from tf2_ros import Buffer, TransformListener, TransformBroadcaster
from geometry_msgs.msg import TransformStamped
from rclpy.duration import Duration

class TfRename(Node):
    def __init__(self):
        super().__init__('tf_rename')
        self.src_parent = self.declare_parameter('src_parent', 'camera_init').get_parameter_value().string_value
        self.src_child  = self.declare_parameter('src_child',  'body').get_parameter_value().string_value
        self.dst_parent = self.declare_parameter('dst_parent', 'odom').get_parameter_value().string_value
        self.dst_child  = self.declare_parameter('dst_child',  'pelvis').get_parameter_value().string_value
        self.declare_parameter('z_lift', 0.8)
        self.z_lift = float(self.get_parameter('z_lift').value)

        self.buf = Buffer(cache_time=Duration(seconds=10.0))
        self.lst = TransformListener(self.buf, self)
        self.br  = TransformBroadcaster(self)

        self.timer = self.create_timer(0.02, self.tick)  # 50 Hz

    def tick(self):
        try:
            t = self.buf.lookup_transform(self.src_parent, self.src_child, rclpy.time.Time())
            out = TransformStamped()
            out.header.stamp = t.header.stamp   # now()->소스시각: 회전 중 각도어긋남 수정 (2026-07-16)
            out.header.frame_id = self.dst_parent
            out.child_frame_id  = self.dst_child
            out.transform.translation.x = t.transform.translation.x
            out.transform.translation.y = t.transform.translation.y
            out.transform.translation.z = t.transform.translation.z + self.z_lift
            out.transform.rotation      = t.transform.rotation
            self.br.sendTransform(out)
        except Exception:
            pass

def main():
    rclpy.init()
    rclpy.spin(TfRename())
    rclpy.shutdown()

if __name__ == '__main__':
    main()
