#!/usr/bin/env python3
# /cmd_vel (geometry_msgs/Twist) -> Go2 sport Move 명령 (/api/sport/request)
# teleop 이나 Nav2가 내는 표준 /cmd_vel 을 로봇 이동으로 바꿔주는 브리지.
#
# 안전장치:
#  - 속도 상한 클램프 (폭주 방지)
#  - 데드맨: DEADMAN_S 동안 새 /cmd_vel 없으면 정지
#  - 10Hz 반복 발행 (Go2는 연속 명령 필요, 안 그러면 곧 멈춤)
#
# ⚠️ 로봇이 서 있는(sport) 상태여야 Move가 먹힘. 엎드림/damp면 먼저 일으켜야 함.
import json
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from unitree_api.msg import Request

SPORT_API_MOVE = 1008        # Go2 sport: Move
MAX_VX = 0.6                  # m/s 전/후
MAX_VY = 0.4                  # m/s 좌/우
MAX_WZ = 0.8                  # rad/s 회전
DEADMAN_S = 0.5              # 이 시간 명령 없으면 정지
RATE_HZ = 10.0


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


class CmdVelToSport(Node):
    def __init__(self):
        super().__init__('cmd_vel_to_sport')
        self.pub = self.create_publisher(Request, '/api/sport/request', 10)
        self.sub = self.create_subscription(Twist, '/cmd_vel', self.on_cmd, 10)
        self.vx = self.vy = self.wz = 0.0
        self.last = self.get_clock().now()
        self._id = 0
        self.was_active = False        # 방금까지 움직임 명령 중이었나
        self.timer = self.create_timer(1.0 / RATE_HZ, self.tick)
        self.get_logger().info('cmd_vel_to_sport 시작: /cmd_vel -> /api/sport/request (Move)')

    def on_cmd(self, msg: Twist):
        self.vx = clamp(msg.linear.x, -MAX_VX, MAX_VX)
        self.vy = clamp(msg.linear.y, -MAX_VY, MAX_VY)
        self.wz = clamp(msg.angular.z, -MAX_WZ, MAX_WZ)
        self.last = self.get_clock().now()

    def _send_move(self, vx, vy, wz):
        req = Request()
        self._id += 1
        req.header.identity.id = self._id
        req.header.identity.api_id = SPORT_API_MOVE
        req.parameter = json.dumps({'x': float(vx), 'y': float(vy), 'z': float(wz)})
        self.pub.publish(req)

    def tick(self):
        dt = (self.get_clock().now() - self.last).nanoseconds * 1e-9
        if dt < DEADMAN_S:
            # 활성: 현재 속도 명령 전송
            self._send_move(self.vx, self.vy, self.wz)
            self.was_active = True
        elif self.was_active:
            # 활성->idle 전환 순간: 정지 명령 딱 한 번 (그 뒤론 조용히)
            self._send_move(0.0, 0.0, 0.0)
            self.was_active = False
        # idle 지속 중엔 아무것도 안 보냄 (Move(0,0,0) 폭격 금지 — 로봇 먹통 방지)


def main():
    rclpy.init()
    node = CmdVelToSport()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
