#!/usr/bin/env python3
# FAST-LIO의 /Laser_map 토픽을 캡처해 PCD로 저장
# (이 포크는 자체 PCD 저장이 고장이라 — 누적코드 주석처리 — 이 스크립트로 대신 저장)
# 사용: 매핑 주행 끝난 뒤, FAST-LIO를 끄기 "전에" 실행!
#   python3 ~/ws/go2_3d/save_map.py [출력파일.pcd]
import os, sys, time
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import PointCloud2

OUT = sys.argv[1] if len(sys.argv) > 1 else \
    time.strftime(os.path.expanduser('~/ws/go2_3d/maps/map_%Y%m%d_%H%M%S.pcd'))

rclpy.init()
node = Node('map_saver')
got = {}
node.create_subscription(PointCloud2, '/Laser_map', lambda m: got.setdefault('m', m), 1)
t0 = time.time()
print('/Laser_map 수신 대기중... (FAST-LIO가 켜져 있어야 함)')
while 'm' not in got and time.time() - t0 < 20:
    rclpy.spin_once(node, timeout_sec=0.3)
m = got.get('m')
if not m:
    print('❌ 수신 실패 — FAST-LIO가 켜져 있는지 확인 (끄기 전에 실행해야 함!)')
    sys.exit(1)

offs = {f.name: f.offset for f in m.fields}
a = np.frombuffer(bytes(m.data), dtype=np.dtype({
    'names': ['x', 'y', 'z', 'intensity'],
    'formats': ['<f4', '<f4', '<f4', '<f4'],
    'offsets': [offs['x'], offs['y'], offs['z'], offs.get('intensity', 16)],
    'itemsize': m.point_step}))
a = a[np.isfinite(a['x']) & np.isfinite(a['y']) & np.isfinite(a['z'])]
n = len(a)

hdr = (f"# .PCD v0.7\nVERSION 0.7\nFIELDS x y z intensity\nSIZE 4 4 4 4\n"
       f"TYPE F F F F\nCOUNT 1 1 1 1\nWIDTH {n}\nHEIGHT 1\n"
       f"VIEWPOINT 0 0 0 1 0 0 0\nPOINTS {n}\nDATA binary\n")
buf = np.zeros(n, dtype=[('x','<f4'),('y','<f4'),('z','<f4'),('intensity','<f4')])
for k in ('x', 'y', 'z', 'intensity'):
    buf[k] = a[k]
with open(OUT, 'wb') as f:
    f.write(hdr.encode())
    f.write(buf.tobytes())
print(f'✅ 저장 완료: {OUT} ({n:,}점)')
rclpy.shutdown()
