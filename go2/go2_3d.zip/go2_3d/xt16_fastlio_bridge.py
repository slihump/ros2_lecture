#!/usr/bin/env python3
# XT16 + Go2 몸통IMU -> FAST-LIO2 입력 브리지
#
# 하는 일 2가지:
#  ① /lidar_points (Hesai 형식: timestamp=절대시각 double)
#     -> /velodyne_points (FAST-LIO velodyne 모드 형식: time=스캔시작 기준 상대초 float)
#     + 헤더시각을 PC 시계로 재스탬핑 (라이다 시계와 PC 시계 차이 제거)
#  ② /lowstate (unitree_go/LowState, 500Hz) 의 imu_state
#     -> /imu/body (sensor_msgs/Imu) + PC 시계로 스탬핑
#
# 왜 재스탬핑? 라이다/로봇/PC 세 장비의 시계가 서로 안 맞으면 LIO가 점과 IMU를
# 잘못 짝지어 지도가 뒤틀림. 셋 다 "PC 도착시각" 기준으로 통일 (데모 수준에선 충분).
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import PointCloud2, PointField, Imu
from unitree_go.msg import LowState

VELO_FIELDS = [
    PointField(name='x',         offset=0,  datatype=PointField.FLOAT32, count=1),
    PointField(name='y',         offset=4,  datatype=PointField.FLOAT32, count=1),
    PointField(name='z',         offset=8,  datatype=PointField.FLOAT32, count=1),
    PointField(name='intensity', offset=12, datatype=PointField.FLOAT32, count=1),
    PointField(name='time',      offset=16, datatype=PointField.FLOAT32, count=1),
    PointField(name='ring',      offset=20, datatype=PointField.UINT16,  count=1),
]
VELO_STEP = 22


class Xt16FastlioBridge(Node):
    def __init__(self):
        super().__init__('xt16_fastlio_bridge')
        best_effort = QoSProfile(depth=5, reliability=ReliabilityPolicy.BEST_EFFORT)
        self.pub_pc = self.create_publisher(PointCloud2, '/velodyne_points', 5)
        self.pub_imu = self.create_publisher(Imu, '/imu/body', 50)
        self.create_subscription(PointCloud2, '/lidar_points', self.on_cloud, 5)
        self.create_subscription(LowState, '/lowstate', self.on_lowstate, best_effort)
        self.n_pc = self.n_imu = 0
        # 라이다시계→PC시계 고정 오프셋 (도착시각 재스탬핑은 프레임마다 ±수십ms 출렁여
        # 보행 중 IMU-점구름 짝맞추기가 틀어짐 → 최소지연 추적으로 지터 제거)
        self.clock_off = None
        self.create_timer(5.0, self.report)
        self.get_logger().info('브리지 시작: /lidar_points->/velodyne_points, /lowstate->/imu/body')

    def on_cloud(self, msg: PointCloud2):
        n = msg.width * msg.height
        if n == 0:
            return
        # Hesai 포인트 파싱 (x f32@0, y@4, z@8, intensity@12, ring u16@16, timestamp f64@18)
        src = np.frombuffer(bytes(msg.data), dtype=np.dtype({
            'names':   ['x', 'y', 'z', 'intensity', 'ring', 'timestamp'],
            'formats': ['<f4', '<f4', '<f4', '<f4', '<u2', '<f8'],
            'offsets': [0, 4, 8, 12, 16, 18],
            'itemsize': msg.point_step}))

        ts = src['timestamp']
        t0 = ts.min()
        dur = float(ts.max() - t0)

        dst = np.zeros(n, dtype=np.dtype({
            'names':   ['x', 'y', 'z', 'intensity', 'time', 'ring'],
            'formats': ['<f4', '<f4', '<f4', '<f4', '<f4', '<u2'],
            'offsets': [0, 4, 8, 12, 16, 20],
            'itemsize': VELO_STEP}))
        dst['x'] = src['x']; dst['y'] = src['y']; dst['z'] = src['z']
        dst['intensity'] = src['intensity']
        dst['time'] = (ts - t0).astype(np.float32)   # 스캔시작 기준 상대초
        dst['ring'] = src['ring']

        out = PointCloud2()
        # 시계 오프셋 갱신: (도착시각 - 스캔끝시각)의 최솟값 ≈ 순수 전송지연+시계차
        now_s = self.get_clock().now().nanoseconds * 1e-9
        inst = now_s - float(ts.max())
        if self.clock_off is None:
            self.clock_off = inst
        else:
            # 최솟값 추적 + 아주 느린 상향 적응(시계 드리프트 대응)
            self.clock_off = min(inst, self.clock_off + 1e-4)
        # 헤더 = 라이다시계의 스캔시작 + 고정오프셋 → 지터 없는 PC시계 기준 스탬프
        stamp_s = float(t0) + self.clock_off
        out.header.stamp.sec = int(stamp_s)
        out.header.stamp.nanosec = int((stamp_s % 1.0) * 1e9)
        out.header.frame_id = msg.header.frame_id
        out.height = 1
        out.width = n
        out.fields = VELO_FIELDS
        out.is_bigendian = False
        out.point_step = VELO_STEP
        out.row_step = VELO_STEP * n
        out.data = dst.tobytes()
        out.is_dense = True
        self.pub_pc.publish(out)
        self.n_pc += 1

    def on_lowstate(self, msg: LowState):
        s = msg.imu_state
        imu = Imu()
        imu.header.stamp = self.get_clock().now().to_msg()
        imu.header.frame_id = 'body_imu'
        # unitree quaternion 순서 = [w, x, y, z]
        imu.orientation.w = float(s.quaternion[0])
        imu.orientation.x = float(s.quaternion[1])
        imu.orientation.y = float(s.quaternion[2])
        imu.orientation.z = float(s.quaternion[3])
        imu.angular_velocity.x = float(s.gyroscope[0])
        imu.angular_velocity.y = float(s.gyroscope[1])
        imu.angular_velocity.z = float(s.gyroscope[2])
        imu.linear_acceleration.x = float(s.accelerometer[0])
        imu.linear_acceleration.y = float(s.accelerometer[1])
        imu.linear_acceleration.z = float(s.accelerometer[2])
        self.pub_imu.publish(imu)
        self.n_imu += 1

    def report(self):
        self.get_logger().info(f'5초간 점구름 {self.n_pc}프레임, IMU {self.n_imu}개 변환')
        self.n_pc = self.n_imu = 0


def main():
    rclpy.init()
    node = Xt16FastlioBridge()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
