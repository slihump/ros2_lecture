#!/bin/bash
# FAST-LIO2 실행 (터미널3용)
# 어떤 터미널에서 실행해도 안전: ROS 환경을 통째로 리셋 후 필요한 것만 소싱.
# (go2ros/unitree 환경이 남아있으면 FAST-LIO가 소리없이 굳는 함정 방지)
unset AMENT_PREFIX_PATH COLCON_PREFIX_PATH CMAKE_PREFIX_PATH PYTHONPATH
unset RMW_IMPLEMENTATION CYCLONEDDS_URI ROS_DOMAIN_ID
# LD_LIBRARY_PATH에서 unitree 경로만 제거
export LD_LIBRARY_PATH=$(echo "$LD_LIBRARY_PATH" | tr ':' '\n' | grep -v unitree_ros2 | paste -sd:)

source /opt/ros/jazzy/setup.bash
source ~/ws/livox/ws_livox/install/setup.bash
source ~/ws/fastlio_ws/install/setup.bash

# DDS는 브리지(터미널2, go2ros 환경)와 반드시 같아야 데이터가 보인다.
# 위에서 RMW를 unset하면 기본값 fastrtps가 되어 cyclonedds인 브리지와 서로 안 보인다
# (토픽이 아예 안 뜨는 원인). 단, unitree_ros2 워크스페이스는 소싱하지 않고
# /opt/ros/jazzy의 시스템 cyclonedds만 쓴다 → 환경 오염 없이 통신만 맞춘다.
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
# 로봇 유선 인터페이스 자동 감지 (setup_go2_ros2.sh와 동일 규칙, enx<MAC> 하드코딩 금지)
_iface="$(ip -o -4 addr show 2>/dev/null | awk '$4 ~ /^192\.168\.123\./ {print $2; exit}')"
if [ -z "$_iface" ]; then
  echo "[run_slam] ⚠️  192.168.123.x 인터페이스를 못 찾았습니다. 랜선/IP 확인 필요."
else
  export CYCLONEDDS_URI="<CycloneDDS><Domain><General><Interfaces>
     <NetworkInterface name=\"$_iface\" priority=\"default\" multicast=\"default\" />
  </Interfaces></General></Domain></CycloneDDS>"
fi

echo "[run_slam] 환경 클린 확인: RMW=$RMW_IMPLEMENTATION (iface ${_iface:-미검출}), unitree 오염=$(echo $AMENT_PREFIX_PATH | grep -c unitree_ros2 || true)"
unset _iface
exec ros2 launch fast_lio mapping.launch.py config_file:=xt16.yaml
